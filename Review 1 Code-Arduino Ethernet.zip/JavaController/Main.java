
/**
 * Class Main. 
 * Contains Main function for the Remote Host app.  
 * Execution starts here. 
 * 
 * @author (Aneesh Neelam) 
 * @version (2013.08.04)
 */

public class Main
{
    public static void main(String args[])
    {
        Program program_instance = new Program();
    }
}

